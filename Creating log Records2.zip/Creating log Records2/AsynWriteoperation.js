let fs = require("fs");
var msg = "This is Asynchronous message store through Fs module";
fs.writeFile("info1.txt",msg,{flag:"a"},(err)=>{
    if(!err){
        console.log("Data store in a file info 1");
        
    }
});
fs.writeFile("info2.txt",msg,{flag:"a"},(err)=>{
    if(!err){
        console.log("Data store in a file info 2");
        
    }
});
console.log("Done...");
console.log("Done...");
//console.log("Done...");