let obj = require("readline-sync");
let id =obj.question("enter the id");
console.log("your id is "+id);
let name =obj.question("enter the name")
console.log("your name is "+name);

