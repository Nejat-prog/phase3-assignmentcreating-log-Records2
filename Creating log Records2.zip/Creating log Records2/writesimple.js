let fs = require("fs"); //loaded core fs module//
let msg = "\n Next message Added to file using nodes js command";
fs.writeFileSync("info.txt",msg{flag:"a"});
console.log("file store successfully...")
console.log("Done...");
console.log("Done...");