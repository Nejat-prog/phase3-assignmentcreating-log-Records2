console.log(__filename);    //current file path
console.log(__dirname);     //dir of current file