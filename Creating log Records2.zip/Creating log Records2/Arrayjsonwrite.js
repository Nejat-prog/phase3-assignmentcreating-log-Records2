let fs = require("fs");
let emp1= '{"id":100,"name":"feruz","salary":1200}';
let emp2= '{"id":101,"name":"mebrke","salary":1300}';
let emp3= '{"id":102,"name":"meraym","salary":1400}';
let emp = new Array();
emp.push(emp1);
emp.push(emp2);
emp.push(emp3);
// convert array object to string
let jsoneData = JSON.stringify(emp);
fs.writeFileSync("employee.json", jsonData);
console.log('file written');

/*let data = fs.readFileSync("employee.json");
console.log(data.toString());
let jsonString = data.toString();
let anotherJSON = JSON.parse(jsonString);
console.log(anotherJSON[0].id);/*



