var obj = require("readline");
let jsonStr = JSON.stringify({'now': new Date()});
console.log(jsonStr);
let r1 = obj.createInterface({
    input:process.stdin,
   output:process.stdout

});
r1.question("what is your firstname?",(firstname)=>{
  r1.question("what is your lastname?",(lastname)=>{
    r1.question("what is your Gender?",(gender)=>{
      r1.question("what is your email?",(email)=>{
   console.log ("your name is "+name+"age is"+lastname);
  // console.log("your fristname is "+fristName"lastName is"+lastName"age is"+age"email is"+email);
   r1.close();   
  })
})
})
});
